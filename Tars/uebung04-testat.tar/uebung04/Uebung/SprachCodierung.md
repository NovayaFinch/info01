# Codierung von Sprachen

## 1
### a
Es müssen 22 verschiedene Symbole dargestellt werden. Die Dezimalzahl 26 hat 5 Stellen im Binärsystem, daher sind 5 Bits nötig um die Symbole darzustelllen.

## 2
### a
Es müssen 26 verschiedene Symbole dargestellt werden. Die Dezimalzahl 26 hat 5 Stellen im Binärsystem, daher sind 5 Bits nötig um die Symbole darzustelllen.
